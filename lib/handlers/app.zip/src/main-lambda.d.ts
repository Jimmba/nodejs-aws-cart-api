import 'reflect-metadata';
export declare const handler: (event: any, context: Context, callback: any) => Promise<any>;
