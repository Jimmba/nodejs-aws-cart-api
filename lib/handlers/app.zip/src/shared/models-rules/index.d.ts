import { AppRequest } from '../models';
export declare function getUserIdFromRequest(request: AppRequest): string;
