"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getUserIdFromRequest = void 0;
function getUserIdFromRequest(request) {
    return request.user && request.user.id;
}
exports.getUserIdFromRequest = getUserIdFromRequest;
//# sourceMappingURL=index.js.map